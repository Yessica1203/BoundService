package co.edu.unipiloto.odometerservice;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Handler;
import android.content.Intent;
import android.util.Log;
import android.widget.TextView;
import java.util.Locale;


public class MainActivity extends AppCompatActivity{

//Constante para hacer referencia a un tipo de permiso mediante una cadena
public static final String PERMISSION_STRING = Manifest.permission.ACCESS_FINE_LOCATION;
    private boolean enlazado = false;
    public OdometerService odometro;
    //declarar escucha de servicios de localizacion
    private LocationListener listener;
    private static double distanciaEnMetros;
    private static Location ultimaLocalizacion = null;
    private LocationManager locManager;
    private TextView log1;

    private ServiceConnection connection =new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            //Codigo a ejecutar cuando se conecte al servicio
          OdometerService.OdometerBinder odometerBinder= (OdometerService.OdometerBinder)
                  iBinder;
          odometro=odometerBinder.getOdometer();
          enlazado=true;
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            // Codigo a ejecutar cuando el servicio se conecta
            enlazado=false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        listener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                //cuando hay cambios en la localizacion
                //Codigo para hacer seguimiento a la distancia
                Log.v("LISTENER-MAIN","On location changed");
                if (ultimaLocalizacion == null) {
                    ultimaLocalizacion = location;
                }
                distanciaEnMetros += location.distanceTo(ultimaLocalizacion);
                ultimaLocalizacion = location;
            }

            @Override
            public void onProviderDisabled(String arg0) {
            }

            @Override
            public void onProviderEnabled(String arg0) {
            }

            @Override
            public void onStatusChanged(String arg0, int arg1, Bundle bundle) {

            }
        };

        Log.v("VALIDANDO PERMISOS", "...");

        if (ActivityCompat.checkSelfPermission(this,
                android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            Log.v("DB", "No aceptados");
        } else {
            Log.v("DB", "PERMISSION GRANTED");
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions)
            Log.v("Aceptados los permisos", "...");
            locManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            if (locManager == null)
                Log.v("Location manager", "null****");
            Log.v("LOCATION MANAGER", locManager.toString());
            String proveedor = null;
            if (ContextCompat.checkSelfPermission(this, PERMISSION_STRING)
                    == PackageManager.PERMISSION_GRANTED)
                proveedor = locManager.getBestProvider(new Criteria(), true);
            Log.v("PROVIDERS", locManager.getAllProviders().get(2).toString());
            if (proveedor != null) {
                Log.v("LOCATION MANAGER", locManager.getAllProviders().toString());
                locManager.requestLocationUpdates(proveedor, 2000, 1, listener);
            } else {
                proveedor = locManager.getAllProviders().get(0);
                Log.v("PROVEEDOR", proveedor);
            }
        } else
            Log.v("PERMISOS", "No aceptados");
        setContentView(R.layout.activity_main);
        mostrarDistancia();
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String [] permissions,
                                           int [] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

        @Override
        public void onStart () {
            super.onStart();
            Intent intent = new Intent(this, OdometerService.class);
            bindService(intent, connection, Context.BIND_AUTO_CREATE);
        }
        @Override
        public void onStop () {
            super.onStop();
            if (enlazado) {
                unbindService(connection);
                enlazado = false;
            }
        }
        //Metodo para mostrar la distancia recorrida y entregada por get distancia en el servicio
        private void mostrarDistancia () {
            TextView verDistancia = (TextView) findViewById(R.id.distancia);
            Handler handler = new Handler();
            //metodo post para el run
            handler.post(new Runnable() {
                @Override
                public void run() {
                    double distancia = 0.0;
                    //Verificar la conexion al servicio
                    if (enlazado && odometro != null)
                        distancia = odometro.getDistancia();
                    //Convertir distancia a String
                    String distanciaStr = String.format(Locale.getDefault(), "%1$,.2f kilometros", distancia);

                    //Actualizar el elemento grafico
                    verDistancia.setText(distanciaStr);
                    handler.postDelayed(this, 2000);
                }
            });
        }
    }
