package co.edu.unipiloto.odometerservice;

import android.Manifest;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Binder;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import java.util.Random;

public class OdometerService extends Service {

    //clase dentro del servicio, para uso dinamico
    private final IBinder binder = new OdometerBinder();
    //Declarar numero aleatorio que suministra el servicio
    private final Random aleatorio = new Random();
    //Declarar escucha de servicios de localizacion
    private LocationListener listener;
    //Declarar variable para acumular la distancia recorrida
    private static double distanciaEnMetros;
    //Para actualizar distancia recorrida, se necesita la ubicacion anterior
    private static Location ultimaLocalizacion = null;
    //Declara un administrador de localizacion
    private LocationManager locManager;

    //Constructor de la clase Odometer
    public OdometerService() {
    }

    public class OdometerBinder extends Binder {
        OdometerService getOdometer() {
            return OdometerService.this;
        }
    }

    @Override //funciona para retornar el binder definido
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        return binder;
    }

    //ontiene el numero real
    public double getDistancia() {
        //retornar la distancia, dividido 1000 metro
        return this.distanciaEnMetros/1000;
        // return aleatorio.nextDouble();
    }

    @Override
    public void onCreate() {
        super.onCreate();
        listener = new LocationListener() {
            @Override
            public void onLocationChanged(@NonNull Location location) {
                //cuando hay cambios en la localizacion
                //Codigo para hacer seguimiento a la distancia
                Log.v("LISTENER - SERVICE ","On location changed");
                if (ultimaLocalizacion == null) {
                    ultimaLocalizacion = location;
                }
                distanciaEnMetros += location.distanceTo(ultimaLocalizacion);
                ultimaLocalizacion = location;
            }

            @Override
            public void onProviderDisabled(String arg0) {
            }

            @Override
            public void onProviderEnabled(String arg0) {
            }

            @Override
            public void onStatusChanged(String arg0, int arg1, Bundle bundle) {

            }
        };
        //Obtener el servico, con una constante Commit_text
            if (ActivityCompat.checkSelfPermission(this,
                    android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                    ActivityCompat.checkSelfPermission(this,
                            android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED ){
                ActivityCompat.requestPermissions(null, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                 Log.v("DB", "No aceptados");
         } else {
            Log.v("DB", "PERMISSION GRANTED");
            }

            locManager =(LocationManager) getSystemService(Context.LOCATION_SERVICE);


        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions)
            Log.v("Aceptados los permisos", "...");
                String proveedor = locManager.getBestProvider(new Criteria(), true);
                Log.v("PROVEDORES",locManager.getAllProviders().get(2).toString());
                if (proveedor != null) {
                    Log.v("LOCATION MANAGER",locManager.getAllProviders().toString());
                    locManager.requestLocationUpdates(proveedor, 2000, 1, listener);
                 }
            }
            else
                Log.v("PERMISOS servicio","NO Aceptados");

    }
    @Override
    public void onDestroy(){
        super.onDestroy();
        if(locManager != null && listener != null){
            locManager.removeUpdates(listener);
        }
        locManager = null;
        listener = null;
    }
}